let mensaje= ("Mostramos un mensaje")
alert(mensaje)